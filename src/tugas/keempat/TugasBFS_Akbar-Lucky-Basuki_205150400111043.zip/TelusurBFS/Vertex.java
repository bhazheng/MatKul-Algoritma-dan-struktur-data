package tugas.keempat.TelusurBFS;

public class Vertex {
    char label;
    boolean wasVisited=false;

    public Vertex(char label) {
        this.label = label;
    }
}
